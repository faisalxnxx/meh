# CrackFb
# How to Installer

$ pkg update && pkg upgrade

$ pkg install git

$ pkg install python2

$ pkg install curl
>
$ git clone https://github.com/Ro0TN3T/CrackFb.git

$ cd CrackFb

$ pip2 install requests

$ pip2 install mechanize

# Run

$ python2 crackfb.py

# Lisensi

< https://pastebin.com/raw/gyYZ8UA0 >
